#!/bin/bash
set -euo pipefail

if [ $# -ne 1 ]; then
    echo "Usage: $0 <encrypted_file>" >&2
    exit 1
fi

INPUT_FILE="$1"
[ ! -f "$INPUT_FILE" ] && { echo "Error: File '$INPUT_FILE' not found!" >&2; exit 1; }

TEMP_FILE=$(mktemp)
cp "$INPUT_FILE" "$TEMP_FILE"

for ((LAYER=10; LAYER>=1; LAYER--)); do
    NEXT_TEMP=$(mktemp)
    
    # Extract EK, EIV, and payload from the script
    EK=$(grep -A1 '^EK=' "$TEMP_FILE" | head -n1 | cut -d'"' -f2)
    EIV=$(grep -A1 '^EIV=' "$TEMP_FILE" | head -n1 | cut -d'"' -f2)
    PAYLOAD_LINE=$(grep -n "^### ENCRYPTED PAYLOAD ###" "$TEMP_FILE" | cut -d: -f1)
    
    # Decode and decrypt
    tail -n +$((PAYLOAD_LINE + 1)) "$TEMP_FILE" | base64 -d > "$NEXT_TEMP.enc"
    openssl enc -d -aes-256-cbc -in "$NEXT_TEMP.enc" -out "$NEXT_TEMP" -K "$EK" -iv "$EIV" -pbkdf2 -iter 100000
    
    mv "$NEXT_TEMP" "$TEMP_FILE"
    rm -f "$NEXT_TEMP.enc"
done

OUTPUT_FILE="${INPUT_FILE%}"
mv "$TEMP_FILE" "$OUTPUT_FILE"
clear
echo "File '$OUTPUT_FILE' Successfully Decrypted"
chmod +x "$OUTPUT_FILE"