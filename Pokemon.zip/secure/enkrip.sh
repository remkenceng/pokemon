#!/bin/bash
set -euo pipefail

if [ $# -ne 1 ]; then
    echo "Usage: $0 <file_to_encrypt>" >&2
    exit 1
fi

INPUT_FILE="$1"
[ ! -f "$INPUT_FILE" ] && { echo "Error: File '$INPUT_FILE' not found!" >&2; exit 1; }

TEMP_FILE=$(mktemp)
cp "$INPUT_FILE" "$TEMP_FILE"

for ((LAYER=1; LAYER<=10; LAYER++)); do
    NEXT_TEMP=$(mktemp)
    EK=$(openssl rand -hex 32)
    EIV=$(openssl rand -hex 16)
    
    # Encrypt with binary output
    openssl enc -aes-256-cbc -salt -in "$TEMP_FILE" -out "$NEXT_TEMP.enc" -K "$EK" -iv "$EIV" -pbkdf2 -iter 100000
    
    # Generate new script with proper base64 payload
    {
        echo '#!/bin/bash'
        echo 'set -euo pipefail'
        echo 'TEMP_DIR=$(mktemp -d)'
        echo 'trap "rm -rf \"\$TEMP_DIR\"" EXIT'
        echo "EK=\"$EK\""
        echo "EIV=\"$EIV\""
        echo 'PAYLOAD_LINE=$(grep -n "^### ENCRYPTED PAYLOAD ###" "$0" | cut -d: -f1)'
        echo 'tail -n +$((PAYLOAD_LINE + 1)) "$0" | base64 -d > "$TEMP_DIR/payload.enc"'
        echo 'openssl enc -d -aes-256-cbc -in "$TEMP_DIR/payload.enc" -out "$TEMP_DIR/payload.dec" -K "$EK" -iv "$EIV" -pbkdf2 -iter 100000'
        echo 'chmod +x "$TEMP_DIR/payload.dec"'
        echo '"$TEMP_DIR/payload.dec" "$@"'
        echo 'exit $?'
        echo '### ENCRYPTED PAYLOAD ###'
        base64 -w0 "$NEXT_TEMP.enc" | tr -d '\n'
    } > "$NEXT_TEMP"
    
    chmod +x "$NEXT_TEMP"
    mv "$NEXT_TEMP" "$TEMP_FILE"
    rm -f "$NEXT_TEMP.enc"
done

mv "$TEMP_FILE" "$INPUT_FILE"
clear
echo "File '$INPUT_FILE' Successfully Encrypted" !